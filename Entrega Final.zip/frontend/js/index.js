import { navbar } from "./navbar.js";

document.getElementById('navbar').innerHTML = navbar;