

window.onload = async function(){
console.log("Holi");

const btn_cerrar_sesion = document.querySelector('#cerrar-sesion');
console.log(btn_cerrar_sesion);



}